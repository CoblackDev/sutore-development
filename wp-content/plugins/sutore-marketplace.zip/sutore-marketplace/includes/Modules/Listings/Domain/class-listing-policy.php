<?php

declare(strict_types=1);

namespace SutoreMarketplace\Modules\Listings\Domain;

use SutoreMarketplace\Modules\Merchants\Support\MerchantMeta;
use SutoreMarketplace\Shared\Domain\MerchantLevels;

final class ListingPolicy
{
    public const ALLOWED_ROLES = ['merchant', 'shop_manager', 'administrator'];

    public static function assertCanManage(?int $userId = null): true|\WP_Error
    {
        $userId = $userId ?: get_current_user_id();
        $user = get_userdata($userId);

        if (!$user) {
            return new \WP_Error('sutore_marketplace_auth', __('You must log in.', 'sutore-marketplace'));
        }

        $roles = (array) $user->roles;
        foreach (self::ALLOWED_ROLES as $role) {
            if (in_array($role, $roles, true)) {
                return true;
            }
        }

        if (user_can($userId, 'manage_woocommerce')) {
            return true;
        }

        return new \WP_Error(
            'sutore_marketplace_forbidden',
            __('You do not have permission for this action.', 'sutore-marketplace')
        );
    }

    public static function assertOwnsListing(Listing $listing, ?int $userId = null): true|\WP_Error
    {
        $userId = $userId ?: get_current_user_id();
        if ((int) $listing->merchantId === (int) $userId) {
            return true;
        }

        if (user_can($userId, 'manage_woocommerce') || user_can($userId, 'edit_others_products')) {
            return true;
        }

        return new \WP_Error(
            'sutore_marketplace_not_owner',
            __('This Listing does not belong to you.', 'sutore-marketplace')
        );
    }

    /**
     * Staff may create listings for another merchant. Non-staff always own as themselves.
     *
     * @param array<string, mixed> $input
     * @param array<string, mixed> $options
     */
    public static function resolveCreateMerchantId(int $actorId, array $input = [], array $options = []): int|\WP_Error
    {
        $requested = (int) ($options['merchant_id'] ?? $input['merchant_id'] ?? 0);
        if ($requested <= 0 || $requested === $actorId) {
            return $actorId;
        }

        if (!user_can($actorId, 'manage_woocommerce')) {
            return new \WP_Error(
                'sutore_marketplace_forbidden',
                __('You do not have permission for this action.', 'sutore-marketplace'),
                ['status' => 403]
            );
        }

        return self::assertValidMerchantTarget($requested);
    }

    public static function assertValidMerchantTarget(int $merchantId): int|\WP_Error
    {
        if ($merchantId <= 0) {
            return new \WP_Error(
                'sutore_marketplace_merchant_required',
                __('Select a seller.', 'sutore-marketplace'),
                ['status' => 400]
            );
        }

        $user = get_userdata($merchantId);
        if (!$user) {
            return new \WP_Error(
                'sutore_marketplace_merchant_missing',
                __('Seller not found.', 'sutore-marketplace'),
                ['status' => 404]
            );
        }

        $roles = (array) $user->roles;
        if (!in_array('merchant', $roles, true)) {
            return new \WP_Error(
                'sutore_marketplace_invalid_merchant',
                __('Select a valid seller.', 'sutore-marketplace'),
                ['status' => 400]
            );
        }

        return $merchantId;
    }

    /**
     * Imported products change delivery time, force a national ID at checkout and skip
     * confirm / cargo deadlines, so only staff may set the flag.
     */
    public static function canFlagImported(?int $userId = null): bool
    {
        $userId = $userId ?: get_current_user_id();

        return user_can($userId, 'manage_woocommerce');
    }

    public static function canUseFastShipment(?int $userId = null): bool
    {
        $userId = $userId ?: get_current_user_id();
        $city = (string) (MerchantMeta::readProfile($userId)[MerchantMeta::ACCOUNT_CITY] ?? '');
        $status = MerchantLevels::statusForUser($userId);
        $requiredCity = \SutoreMarketplace\Shared\Settings\Settings::fastShipmentCity();
        $allowedLevels = \SutoreMarketplace\Shared\Settings\Settings::fastShipmentLevels();

        return $city === $requiredCity && in_array($status, $allowedLevels, true);
    }

    /** Onaylı / Premium satıcılar bedendeki tüm satış fiyatlarını görebilir. */
    public static function canViewCompetingPrices(?int $userId = null): bool
    {
        $userId = $userId ?: get_current_user_id();
        if (user_can($userId, 'manage_woocommerce')) {
            return true;
        }

        $status = MerchantLevels::statusForUser($userId);

        return in_array($status, [MerchantLevels::VERIFIED, MerchantLevels::PREMIUM], true);
    }
}
